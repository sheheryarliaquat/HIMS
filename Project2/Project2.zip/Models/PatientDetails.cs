﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project2.Models
{
    public class PatientDetails
    {
        public int MR_no;
        public string FIRST_NAME ;
        public string ADDRESS1;
        public string f_name;
        public string TEL_NO;
    }
}